import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './customers.css';

function Customers() {
    const [customers, setCustomers] = useState([]);

    useEffect(() => {
        const fetchCustomers = async () => {
            try {
                const response = await axios.get('http://localhost:8080/admin/customers');
                if (response.data && response.data.status === "success") {
                    console.log('Fetched Customers:', response.data.data);
                    setCustomers(response.data.data);
                } else {
                    console.log('No data received or error status');
                    setCustomers([]); // Ensure state is updated in case of no data
                }
            } catch (error) {
                console.error('Error fetching customers:', error);
                setCustomers([]); // Set an empty array on error
            }
        };

        fetchCustomers();
    }, []);

    return (
        <div className="customers-container">
            <h2>Customers</h2>
            <ul className="customers-list">
                {Array.isArray(customers) && customers.length > 0 ? (
                    customers.map((customer, index) => (
                        <li key={index} className="customer-item">
                            <h3>{customer.firstName} {customer.lastName}</h3>
                            <p><strong>Email:</strong> {customer.email}</p>
                            <p><strong>Mobile No:</strong> {customer.mobileNo}</p>
                        </li>
                    ))
                ) : (
                    <li>No customers found</li>
                )}
            </ul>
        </div>
    );
}

export default Customers;
